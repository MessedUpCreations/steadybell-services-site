SteadyBell missing folders patch

Upload the two folders below to the ROOT of your GitHub repository:

assets/
  steadybell-logo.svg
  favicon.svg

api/
  contact.js

Do not put the folders inside another steadybell-services-site folder.
After committing, Vercel should automatically redeploy.
